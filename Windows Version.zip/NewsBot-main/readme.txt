Just a bot that gives you news.

Simply paste your bot token inside "PUT_TOKEN_HERE.txt"

Once up, do !settings to have the bot set up the way you like it.

Requires Discord.py and GoogleNews
Install Command: pip install discordpy&&pipinstall googlenews

Launch command: python main.py
